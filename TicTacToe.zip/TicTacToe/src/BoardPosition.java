
public class BoardPosition {

	public int row;
	public int col;

	public BoardPosition(int x, int y) {
		this.row = x;
		this.col = y;
	}
	
}
