
public class InvalidMove extends Exception {

}
