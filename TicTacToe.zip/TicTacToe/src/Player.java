
public enum Player {
	P1("P1"), P2("P2");
	
	public String marker;
	private Player(String marker) {
		this.marker = marker;
	}
	
}
