
public class PutAction extends PlayerAction {
	
	public BoardPosition position;
	
	public PutAction(BoardPosition position) {
		this.position = position;
	}

}
